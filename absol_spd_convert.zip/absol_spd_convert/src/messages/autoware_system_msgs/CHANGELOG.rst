^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package autoware_system_msgs
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.13.0 (2019-12-03)
-------------------
* Update emergency category in DiagnosticStatus message
* Update package.xml files to Format 2.
* Contributors: Joshua Whitley, Yuma Nihei

1.12.0 (2019-07-12)
-------------------

1.11.0 (2019-03-21)
-------------------
* Revert "Fix/health checker (`#2012 <https://github.com/CPFL/Autoware/issues/2012>`_)" (`#2037 <https://github.com/CPFL/Autoware/issues/2037>`_)
  This reverts commit e4187a7138eb90ad6f119eb35f824b16465aefda.
  Reverts `#2012 <https://github.com/CPFL/Autoware/issues/2012>`_
  Merged without adequate description of the bug or fixes made
* Fix/health checker (`#2012 <https://github.com/CPFL/Autoware/issues/2012>`_)
* Feature/autoware health analyzer (`#2004 <https://github.com/CPFL/Autoware/issues/2004>`_)
* Feature/autoware health checker (`#1943 <https://github.com/CPFL/Autoware/issues/1943>`_)
* Contributors: Geoffrey Biggs, Masaya Kataoka
